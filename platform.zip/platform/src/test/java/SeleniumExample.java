import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumExample {
    public static void main(String[] args) {
        // Automatically manage the ChromeDriver binary
        WebDriverManager.chromedriver().driverVersion("114.0.5735.90").setup();

        WebDriver driver = new ChromeDriver();
        driver.get("https://www.example.com");

        // Your testing code goes here

        driver.quit();
    }
}



